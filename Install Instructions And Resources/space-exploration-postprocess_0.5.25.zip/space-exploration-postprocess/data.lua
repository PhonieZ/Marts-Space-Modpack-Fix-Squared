local data_util = require("data_util")

local se_dependencies = { -- copy in from info.json
    "base >= 1.1.34",
    "aai-industry >= 0.5.3",
    "alien-biomes >= 0.6.4",
    "jetpack >= 0.2.6",
    "robot_attrition >= 0.5.9",
    "shield-projector >= 0.1.2",
    "space-exploration-graphics = 0.5.14",
    "space-exploration-graphics-2 >= 0.1.1",
    "space-exploration-graphics-3 >= 0.1.1",
    "space-exploration-graphics-4 >= 0.1.1",
    "space-exploration-graphics-5 >= 0.1.2",
    "~ space-exploration-postprocess >= 0.5.25",
    "informatron >= 0.2.1",
    "aai-signal-transmission >= 0.4.1",

    "? space-exploration-hr-graphics >= 0.5.1",
    "? aai-containers >= 0.2.7",
    "? bullet-trails >= 0.6.1",
    "? grappling-gun >= 0.3.1",
    "? combat-mechanics-overhaul >= 0.6.15",
    "? equipment-gantry >= 0.1.1",

    "! angelsindustries",
    "! angelspetrochem",
    "! angelsrefining",
    "! angelssmelting",

    "! bobelectronics",
    "! bobores",
    "! bobplates",
    "! bobpower",
    "! bobrevamp",
    "! bobtech",
    "! bobvehicleequipment",
    "! bobwarfare",

    "! Yuoki",

    "! pycoalprocessing",
    "! pyindustry",
    "! pyhightech",

    "! ab_logisticscenter",
    "! angelsinfiniteores",
    "! BasicSeaBlock",
    "! BitersBegone",
    "! BitersBegoneUpdated",
    "! bobmodules",
    "! bulkteleport",
    "! Clockwork",
    "! dangOreus",
    "! dark-matter-replicators",
    "! dark-matter-replicators-0_17-port",
    "! DeepMine",
    "! endlessresources",
    "! Explosive Excavation",
    "! FactorioExtended-Core",
    "! FactorioExtended-Plus-Core",
    "! IndustrialRevolution",
    "! IndustrialRevolution2",
    "! inf_res",
    "! infinite-resources-depletion",
    "! ItemTeleportation",
    "! LandfillPainting",
    "! modmash",
    "! MoreScience",
    "! MoreSciencePacks",
    "! omnimatter",
    "! OnlyReds",
    "! PersonalTeleporter",
    "! pickerextended",
    "! pickerinventorytools",
    "! PlacePump",
    "! PumpAnywhere",
    "! PyBlock",
    "! railgun_revival",
    "! rso-mod",
    "! SeaBlock",
    "! SchallMachineScaling",
    "! SchallOreConversion",
    "! sonaxaton-infinite-resources",
    "! SpaceMod",
    "! TagToTeleport",
    "! TeamCoop",
    "! Teleportation_Redux",
    "! traintunnels",
    "! Unlimited-Resources",
    "! UnlimitedProductivity",
    "! vtk-deep-core-mining",
    "! warptorio"
}

local log_always = false -- always print diagnostics result to log, not only if there's an issue

if log_always or not mods["space-exploraiton"] then
  -- space exploration didn't load.
  -- find the reason why.

  local function split_version (version)
    result = {}
    for match in (version.."."):gmatch("(.-)"..".") do
      table.insert(result,tonumber (match))
    end
    return result
  end

  local function test_version (version, test)
    version = split_version (version)
    test = split_version (test)

    for i = 1, 3 do
      if test[i] > version[i] then
        return false
      elseif test[i] < version[i] then
        return true
      end
    end
    return true
  end

  local message = "Beginning Space Exploration diagnostics: \n"

  for k, dependency in pairs(se_dependencies) do
    -- remove the orderless flag ~
    dependency = data_util.replace(dependency, "~ ", "")
    dependency = data_util.replace(dependency, "~", "")
    local dependency_split = data_util.string_split(dependency, " ")

    if dependency_split[1] == "!" then
      -- conflict
      local dependency_split = data_util.string_split(dependency, " ")
      if mods[dependency_split[2]] then
        message = message .. "Conflicting mod " .. dependency_split[2] .. " detected.\n"
      end
    elseif dependency_split[1] == "?" or dependency_split[1] == "(?)" then
      -- optional
      if mods[dependency_split[2]] then
        if dependency_split[3] == ">" then
          if not data_util.dot_string_greater_than(mods[dependency_split[2]], dependency_split[4], false) then
            message = message .. "Optional mod " .. dependency_split[2] .. " has incompatible version: "
              ..mods[dependency_split[2]].." "..dependency_split[3].." "..dependency_split[4].."\n"
          end
        elseif dependency_split[3] == ">=" then
          if not data_util.dot_string_greater_than(mods[dependency_split[2]], dependency_split[4], true) then
            message = message .. "Optional mod " .. dependency_split[2] .. " has incompatible version: "
              ..mods[dependency_split[2]].." "..dependency_split[3].." "..dependency_split[4].."\n"
          end
        end
        -- TODO: Other comparisons
      end
    else
      -- required
      if not mods[dependency_split[1]] then
        message = message .. "Required mod ".. dependency_split[1] .. " missing.\n"
      elseif dependency_split[2] == ">" then
        if not data_util.dot_string_greater_than(mods[dependency_split[1]], dependency_split[3], false) then
          message = message .. "Required mod " .. dependency_split[1] .. " has incompatible version: "
            ..mods[dependency_split[1]].." "..dependency_split[2].." "..dependency_split[3].."\n"
        end
      elseif dependency_split[2] == ">=" then
        if not data_util.dot_string_greater_than(mods[dependency_split[1]], dependency_split[3], true) then
          message = message .. "Required mod " .. dependency_split[1] .. " has incompatible version: "
            ..mods[dependency_split[1]].." "..dependency_split[2].." "..dependency_split[3].."\n"
        end
      end
    end
    se_dependencies[k] = dependency
  end

  if message == "Beginning Space Exploration diagnostics: \n" then
    if not mods["space-exploration"] then
      message = message .. "Space Exploration is not installed or active."
    else
      message = message .. "No problems detected."
    end
  end

  log (message)
end
