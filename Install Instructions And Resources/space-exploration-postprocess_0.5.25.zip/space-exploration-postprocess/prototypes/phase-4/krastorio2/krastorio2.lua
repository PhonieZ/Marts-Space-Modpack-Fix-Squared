local data_util = require("data_util")

if mods["Krastorio2"] then

  -- -- Changing science packs icons to Krastorio 2 design for on planet techs
  -- Automation science pack
  krastorio.icons.setItemIcon("automation-science-pack", kr_cards_icons_path .. "automation-tech-card.png")
  data.raw.tool["automation-science-pack"].order = "b02[automation-tech-card]"
  krastorio.icons.setTechnologyIcon("automation-science-pack", kr_technologies_icons_path .. "automation-tech-card.png", 256, 4)

  -- Logistic science pack
  krastorio.icons.setItemIcon("logistic-science-pack", kr_cards_icons_path .. "logistic-tech-card.png")
  data.raw.tool["logistic-science-pack"].order = "b03[logistic-tech-card]"
  krastorio.icons.setTechnologyIcon("logistic-science-pack", kr_technologies_icons_path .. "logistic-tech-card.png", 256, 4)

  -- Military science pack
  krastorio.icons.setItemIcon("military-science-pack", kr_cards_icons_path .. "military-tech-card.png")
  data.raw.tool["military-science-pack"].order = "b04[military-tech-card]"
  krastorio.icons.setTechnologyIcon("military-science-pack", kr_technologies_icons_path .. "military-tech-card.png", 256, 4)

  -- Chemical science pack
  krastorio.icons.setItemIcon("chemical-science-pack", kr_cards_icons_path .. "chemical-tech-card.png")
  data.raw.tool["chemical-science-pack"].order = "b05[chemical-tech-card]"
  krastorio.icons.setTechnologyIcon("chemical-science-pack", kr_technologies_icons_path .. "chemical-tech-card.png", 256, 4)

  -- Production science pack
  krastorio.icons.setItemIcon("production-science-pack", kr_cards_icons_path .. "production-tech-card.png")
  data.raw.tool["production-science-pack"].order = "b06[production-tech-card]"
  krastorio.icons.setTechnologyIcon("production-science-pack",    kr_technologies_icons_path .. "production-tech-card.png", 256, 4)

  -- Utility science pack
  krastorio.icons.setItemIcon("utility-science-pack", kr_cards_icons_path .. "utility-tech-card.png")
  data.raw.tool["utility-science-pack"].order = "b07[utility-tech-card]"
  krastorio.icons.setTechnologyIcon("utility-science-pack", kr_technologies_icons_path .. "utility-tech-card.png", 256, 4)

  -- Space science pack
  krastorio.icons.setItemIcon("space-science-pack", kr_cards_icons_path .. "optimization-tech-card.png")
  data.raw.tool["space-science-pack"].order = "b09[optimization-tech-card]"
  krastorio.icons.setTechnologyIcon("space-science-pack", kr_technologies_icons_path .. "optimization-tech-card.png", 256, 4)
  data.raw.recipe["space-science-pack"].category = "t2-tech-cards"

  -- move some k2 things earlier in the tech tree. Distribute between late rocket science and T4 specialist science.
  -- anything relating to space warping, ingularities, matter, or antimatter should be after deep space science
  -- fusion should be around energy science 3.
  data_util.tech_remove_ingredients("kr-imersium-processing", {"matter-tech-card"})
  data_util.tech_remove_prerequisites("kr-imersium-processing", {"kr-matter-tech-card"})
  data_util.tech_add_ingredients("kr-imersium-processing", {"se-rocket-science-pack"})
  data_util.tech_add_prerequisites("kr-imersium-processing", {"se-rocket-science-pack", "kr-quarry-minerals-extraction"})

  data_util.tech_remove_ingredients("kr-energy-control-unit", {"matter-tech-card"})
  data_util.tech_remove_prerequisites("kr-energy-control-unit", {"kr-matter-tech-card", "kr-singularity-lab"})
  data_util.tech_add_ingredients("kr-energy-control-unit", {"se-energy-science-pack-1"})
  data_util.tech_add_prerequisites("kr-energy-control-unit", {"se-energy-science-pack-1"})


  local function move_to_specialist_science_packs(tech_name, science_packs, require_imersium)
    data_util.tech_remove_ingredients(tech_name, {"space-science-pack", "matter-tech-card", "advanced-tech-card", "se-deep-space-science-pack-1"})
    data_util.tech_remove_prerequisites(tech_name, {"space-science-pack", "kr-matter-tech-card", "kr-advanced-tech-card", "se-deep-space-science-pack-1"})
    data_util.tech_add_ingredients(tech_name, science_packs)
    data_util.tech_add_prerequisites(tech_name, science_packs)
    if require_imersium then
      data_util.tech_add_prerequisites(tech_name, {"kr-imersium-processing"})
    end
  end

  -- EDW: Test to move artillery range + artillery shot speed from DSS1 to Rocket Science.
  -- Artillery Range.
  -- Level 3 prereqs requires only Rocket Science tech adding.
  move_to_specialist_science_packs("artillery-shell-range-3", {"se-rocket-science-pack"})
  data_util.tech_add_ingredients("artillery-shell-range-3", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack"})

  -- Further levels benefit from the function, but require prereq Rocket Science removing, as Level 3 already has this prereq.
  move_to_specialist_science_packs("artillery-shell-range-4", {"space-science-pack"})
  data_util.tech_remove_prerequisites("artillery-shell-range-4", {"se-rocket-science-pack"})
  data_util.tech_add_ingredients("artillery-shell-range-4", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack"})

  -- Further levels include Singularity tech, which is not caught by the function and thus should be manually removed from further levels.
  -- Due to the inclusion of Singularity tech at this level, the cost is less than previous levels. Adapting this could be the source of a further change.
  move_to_specialist_science_packs("artillery-shell-range-5", {"se-material-science-pack-1"})
  data_util.tech_remove_ingredients("artillery-shell-range-5", {"singularity-tech-card"})
  data_util.tech_remove_prerequisites("artillery-shell-range-5",{"se-rocket-science-pack","kr-singularity-tech-card"})
  data_util.tech_add_ingredients("artillery-shell-range-5", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack", "space-science-pack"})

  move_to_specialist_science_packs("artillery-shell-range-6", {"se-material-science-pack-2"})
  data_util.tech_remove_ingredients("artillery-shell-range-6", {"singularity-tech-card"})
  data_util.tech_remove_prerequisites("artillery-shell-range-6",{"se-rocket-science-pack","kr-singularity-tech-card"})
  data_util.tech_add_ingredients("artillery-shell-range-6", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack", "space-science-pack"})

  move_to_specialist_science_packs("artillery-shell-range-7", {"se-material-science-pack-3"})
  data_util.tech_remove_ingredients("artillery-shell-range-7", {"singularity-tech-card"})
  data_util.tech_remove_prerequisites("artillery-shell-range-7",{"se-rocket-science-pack","kr-singularity-tech-card"})
  data_util.tech_add_ingredients("artillery-shell-range-7", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack", "space-science-pack"})

  move_to_specialist_science_packs("artillery-shell-range-8", {"se-material-science-pack-4"})
  data_util.tech_remove_ingredients("artillery-shell-range-8", {"singularity-tech-card"})
  data_util.tech_remove_prerequisites("artillery-shell-range-8",{"se-rocket-science-pack","kr-singularity-tech-card"})
  data_util.tech_add_ingredients("artillery-shell-range-8", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack", "space-science-pack"})

  -- Level 9 is the first of the infinite upgrade series, thus it is the last needing these changes.
  move_to_specialist_science_packs("artillery-shell-range-9", {"se-deep-space-science-pack-1"})
  data_util.tech_remove_ingredients("artillery-shell-range-9", {"singularity-tech-card"})
  data_util.tech_remove_prerequisites("artillery-shell-range-9",{"se-rocket-science-pack","kr-singularity-tech-card"})
  data_util.tech_add_ingredients("artillery-shell-range-9", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack", "space-science-pack"})

  -- Artillery Shell Speed.
  move_to_specialist_science_packs("artillery-shell-speed-3", {"se-rocket-science-pack"})
  data_util.tech_add_ingredients("artillery-shell-speed-3", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack"})

  move_to_specialist_science_packs("artillery-shell-speed-4", {"space-science-pack"})
  data_util.tech_remove_prerequisites("artillery-shell-speed-4", {"se-rocket-science-pack"})
  data_util.tech_add_ingredients("artillery-shell-speed-4", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack"})

  move_to_specialist_science_packs("artillery-shell-speed-5", {"se-material-science-pack-1"})
  data_util.tech_remove_ingredients("artillery-shell-speed-5", {"singularity-tech-card"})
  data_util.tech_remove_prerequisites("artillery-shell-speed-5",{"se-rocket-science-pack","kr-singularity-tech-card"})
  data_util.tech_add_ingredients("artillery-shell-speed-5", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack", "space-science-pack"})

  move_to_specialist_science_packs("artillery-shell-speed-6", {"se-material-science-pack-2"})
  data_util.tech_remove_ingredients("artillery-shell-speed-6", {"singularity-tech-card"})
  data_util.tech_remove_prerequisites("artillery-shell-speed-6",{"se-rocket-science-pack","kr-singularity-tech-card"})
  data_util.tech_add_ingredients("artillery-shell-speed-6", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack", "space-science-pack"})

  move_to_specialist_science_packs("artillery-shell-speed-7", {"se-material-science-pack-3"})
  data_util.tech_remove_ingredients("artillery-shell-speed-7", {"singularity-tech-card"})
  data_util.tech_remove_prerequisites("artillery-shell-speed-7",{"se-rocket-science-pack","kr-singularity-tech-card"})
  data_util.tech_add_ingredients("artillery-shell-speed-7", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack", "space-science-pack"})

  move_to_specialist_science_packs("artillery-shell-speed-8", {"se-material-science-pack-4"})
  data_util.tech_remove_ingredients("artillery-shell-speed-8", {"singularity-tech-card"})
  data_util.tech_remove_prerequisites("artillery-shell-speed-8",{"se-rocket-science-pack","kr-singularity-tech-card"})
  data_util.tech_add_ingredients("artillery-shell-speed-8", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack", "space-science-pack"})

  move_to_specialist_science_packs("artillery-shell-speed-9", {"se-deep-space-science-pack-1"})
  data_util.tech_remove_ingredients("artillery-shell-speed-9", {"singularity-tech-card"})
  data_util.tech_remove_prerequisites("artillery-shell-speed-9",{"se-rocket-science-pack","kr-singularity-tech-card"})
  data_util.tech_add_ingredients("artillery-shell-speed-9", {"automation-science-pack","logistic-science-pack","military-science-pack","chemical-science-pack", "space-science-pack"})
  --EDW: End changed code.

  if data.raw.technology["kr-radar"] then
    data.raw.technology["kr-radar"].prerequisites = {"optics"}
    data_util.tech_remove_ingredients("kr-radar", {"logistic-science-pack"})
  end

  if data.raw.technology["advanced-radar"] then
    data.raw.technology["advanced-radar"].prerequisites = {"laser", data.raw.technology["kr-radar"] and "kr-radar" or nil}
    data_util.tech_add_ingredients("advanced-radar", {"chemical-science-pack"})
    data_util.tech_remove_ingredients("advanced-rada", {"singularity-tech-card"})
  end

  move_to_specialist_science_packs("kr-superior-inserters", {"se-energy-science-pack-1"}, true)

  move_to_specialist_science_packs("kr-personal-laser-defense-mk3-equipment", {"se-energy-science-pack-2"}, true)
  data_util.tech_add_ingredients("kr-personal-laser-defense-mk3-equipment", {"military-science-pack"})

  move_to_specialist_science_packs("kr-fusion-energy", {"se-energy-science-pack-3"})
  move_to_specialist_science_packs("fusion-reactor-equipment", {"se-energy-science-pack-3"})

  move_to_specialist_science_packs("kr-laser-artillery-turret", {"se-energy-science-pack-2"}, true)
  data_util.tech_add_prerequisites("kr-laser-artillery-turret", {"se-holmium-solenoid"})
  data_util.replace_or_add_ingredient("kr-laser-artillery-turret", "ai-core", "se-holmium-solenoid", 20)


  move_to_specialist_science_packs("kr-advanced-furnace", {"se-material-science-pack-1"}, true)
  move_to_specialist_science_packs("kr-rocket-turret", {"se-material-science-pack-1"})
  data_util.tech_add_prerequisites("kr-laser-artillery-turret", {"se-heavy-girder"})
  data_util.replace_or_add_ingredient("kr-rocket-turret", "steel-beam", "se-heavy-girder", 10)

  move_to_specialist_science_packs("kr-power-armor-mk3", {"se-material-science-pack-2"}, true)
  data_util.replace_or_add_ingredient("power-armor-mk3", nil, "se-iridium-plate", 25)

  move_to_specialist_science_packs("kr-advanced-tank", {"se-material-science-pack-2"})
  data_util.tech_add_ingredients("kr-advanced-tank", {"military-science-pack"}, true)
  move_to_specialist_science_packs("kr-automation", {"se-material-science-pack-2"})
  data_util.tech_add_prerequisites("kr-automation", {"se-heavy-bearing"})
  data_util.replace_or_add_ingredient("kr-advanced-assembling-machine", "ai-core", "se-heavy-bearing", 10)

  move_to_specialist_science_packs("kr-electric-mining-drill-mk3", {"se-material-science-pack-3"})
  data_util.replace_or_add_ingredient("kr-electric-mining-drill-mk3", "ai-core", "se-heavy-bearing", 10)

  move_to_specialist_science_packs("kr-creep-virus", {"se-biological-science-pack-1"})
  move_to_specialist_science_packs("kr-advanced-chemical-plant", {"se-biological-science-pack-2"})
  move_to_specialist_science_packs("kr-biter-virus", {"se-biological-science-pack-3"})

  data_util.tech_remove_prerequisites("spidertron", {"kr-ai-core", "space-science-pack", "kr-matter-tech-card", "kr-advanced-tech-card", "se-deep-space-science-pack"})
  move_to_specialist_science_packs("spidertron", {"se-biological-science-pack-1"})

  -- Integrate the k2 computer so it is not left around chemical science with nothing to do for half the game.

  data_util.tech_add_prerequisites("kr-advanced-roboports", {"kr-ai-core"})

  data_util.tech_add_prerequisites("kr-advanced-tech-card", {"kr-singularity-lab"})

  data_util.tech_add_prerequisites("kr-ai-core", {"se-deep-space-science-pack-1"})
  data_util.tech_add_ingredients("kr-ai-core", {"se-deep-space-science-pack-1"})
  table.insert(data.raw.recipe["ai-core"].ingredients, {type = "fluid", name = "se-neural-gel-2", amount = 2})
  data_util.replace_or_add_ingredient("ai-core", "processing-unit", "se-quantum-processor", 2)
  data_util.replace_or_add_ingredient("ai-core", nil, "se-naquium-plate", 1)

  data_util.tech_add_prerequisites("kr-quantum-computer", {"kr-imersium-processing", "se-deep-space-science-pack-1"})
  data_util.tech_add_ingredients("kr-quantum-computer", {"se-deep-space-science-pack-1"})
  data_util.replace_or_add_ingredient("kr-quantum-computer", "steel-beam", "imersium-beam", 20)
  data_util.replace_or_add_ingredient("kr-quantum-computer", nil, "se-quantum-processor", 50)

  data_util.tech_add_prerequisites("kr-fusion-energy", {"se-space-particle-collider"})
  data_util.tech_add_prerequisites("kr-antimatter-reactor", {"se-antimatter-reactor"})

  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-energy-science-pack-1")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-energy-science-pack-2")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-energy-science-pack-3")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-energy-science-pack-4")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-astronomic-science-pack-1")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-astronomic-science-pack-2")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-astronomic-science-pack-3")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-astronomic-science-pack-4")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-biological-science-pack-1")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-biological-science-pack-2")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-biological-science-pack-3")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-biological-science-pack-4")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-material-science-pack-1")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-material-science-pack-2")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-material-science-pack-3")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-material-science-pack-4")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-deep-space-science-pack-1")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-deep-space-science-pack-2")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-deep-space-science-pack-3")
  table.insert(data.raw.lab["kr-singularity-lab"].inputs, "se-deep-space-science-pack-4")
  local lab = data.raw.lab["kr-singularity-lab"]
  local ssp = 0
  for i, pack in pairs(lab.inputs) do
    if pack == "space-science-pack" then
      ssp = ssp + 1
      if ssp > 1 then
        lab.inputs[i]=nil
      end
    end
  end

  if data.raw.item["biusart-lab"] then
    data_util.replace_or_add_ingredient("se-space-science-lab", "lab", "biusart-lab", 10)
    data_util.tech_add_prerequisites("se-space-science-lab", {"kr-advanced-lab"})
  end

  data.raw.recipe["kr-singularity-lab"].ingredients = { -- this needs to change too much to make item by item changes
    {"se-space-science-lab", 1},
    {"se-naquium-cube", 4},
    {"ai-core", 50},
    {"imersium-plate", 50},
    {"imersium-beam", 50},
  }

  data_util.tech_add_prerequisites("kr-matter-tech-card", {"se-deep-space-science-pack-2", "se-naquium-tessaract"})
  data_util.techs_add_ingredients({"kr-matter-tech-card"}, {"se-deep-space-science-pack-2"}, true)
  data_util.tech_add_prerequisites("kr-matter-processing", {"se-space-matter-fusion"})
  data_util.replace_or_add_ingredient("matter-stabilizer", nil, "se-naquium-tessaract", 1)

  data_util.tech_add_prerequisites("kr-singularity-tech-card", {"se-deep-space-science-pack-4"})
  data_util.techs_add_ingredients({"kr-singularity-tech-card"}, {"se-deep-space-science-pack-4"}, true)
  data_util.replace_or_add_ingredient("kr-singularity-tech-card", nil, "se-naquium-processor", 1)


  if data.raw.beacon["kr-singularity-beacon"] then
    -- Advanced Beacon
    local beacon = data.raw.beacon["kr-singularity-beacon"]
    beacon.energy_usage = "400kW"
    beacon.supply_area_distance = 2 -- The limiting factor is the very short range.
    beacon.distribution_effectivity = 0.75
    --beacon.distribution_effectivity = 0.666666666667
    beacon.module_specification = {
      module_info_icon_shift = {0, 0.5},
      module_info_max_icons_per_row = 5,
      module_info_max_icon_rows = 3,
      module_info_multi_row_initial_height_modifier = -0.5,
      module_slots = 15,
      module_info_icon_scale = 0.3
    } -- 0.75 * 15 slots = 10.5. Max for wide are beacons is 10.
    -- Means these are the most powerful beacons, and they are available earliest after normal beacons.
    data_util.tech_remove_ingredients("kr-singularity-beacon", {"space-science-pack", "matter-tech-card", "advanced-tech-card", "singularity-tech-card", "se-deep-space-science-pack-1"})
    data_util.tech_add_ingredients("kr-singularity-beacon", {"se-energy-science-pack-1"})
    data.raw.technology["kr-singularity-beacon"].prerequisites = {"effect-transmission", "se-holmium-cable", "kr-energy-control-unit"}
    data_util.replace_or_add_ingredient("kr-singularity-beacon", "ai-core", "se-holmium-cable", 40)
    --data_util.replace_or_add_ingredient("kr-singularity-beacon", nil, data_util.mod_prefix .. "energy-catalogue-1", 1)

    data.raw.technology["se-wide-beacon"].prerequisites = {"effect-transmission", "kr-energy-control-unit", "se-superconductive-cable"}
    data_util.tech_remove_ingredients("se-wide-beacon", {"se-energy-science-pack-1"})
    data_util.tech_add_ingredients("se-wide-beacon", {"se-energy-science-pack-3"})
    data_util.replace_or_add_ingredient("se-wide-beacon", "se-holmium-cable", "se-superconductive-cable", 40)

    data.raw.technology["se-wide-beacon-2"].prerequisites = {"se-wide-beacon", "se-dynamic-emitter", "se-naquium-processor", "kr-singularity-tech-card"}
    data_util.tech_add_ingredients("se-wide-beacon-2", {"singularity-tech-card"})
    data_util.replace_or_add_ingredient("se-wide-beacon-2", "se-superconductive-cable", "ai-core", 10)

  end

  local adv_furnace = data.raw["assembling-machine"]["kr-advanced-furnace"]
  adv_furnace.crafting_speed = 8
  adv_furnace.module_specification.module_slots = 5

  data_util.replace_or_add_ingredient("matter-stabilizer", nil, "se-naquium-cube", 1)

  data_util.replace_or_add_ingredient("kr-matter-plant", nil, "se-naquium-tessaract", 1)
  data_util.replace_or_add_ingredient("kr-matter-assembler", nil, "se-naquium-tessaract", 1)

  data_util.tech_remove_prerequisites("se-space-decontamination-facility", {"se-rocket-science-pack"})

  data_util.replace_or_add_ingredient("kr-antimatter-reactor", nil, "se-naquium-processor", 10)
  data_util.replace_or_add_ingredient("kr-antimatter-reactor", nil, "se-naquium-plate", 350)
  data_util.replace_or_add_ingredient("kr-antimatter-reactor", "steel-plate", "se-antimatter-reactor", 1)

  data_util.replace_or_add_ingredient("antimatter-reactor-equipment", nil, "se-naquium-processor", 1)



  -- TODO: move adv robotports somewhere maybe?
  -- make the SE fuel refinery into an advanced refinery?
  -- fix the energy shield placements and tech requirements.

  if data.raw.item["space-research-data"] and not data.raw.recipe["space-research-data"] then
    data:extend({
      {
          type = "recipe",
          name = "space-research-data",
          enabled = false,
          energy_required = 1,
          ingredients = {
            { "se-iridium-plate", 2 },
            { "se-holmium-plate", 2 },
            { "se-beryllium-plate", 2 },
            { "se-vitamelange-extract", 2 },
            { "imersium-plate", 2 },
          },
          results = {
            {"space-research-data", 1},
          },
          main_product = "space-research-data",
          requester_paste_multiplier = 1,
          subgroup = "science-pack",
          category = "t2-tech-cards"
      }
    })
    data_util.recipe_require_tech("space-research-data", "space-science-pack")
    if not data_util.table_contains(data.raw.lab["se-space-science-lab"].inputs, "space-science-pack") then
      table.insert(data.raw.lab["se-space-science-lab"].inputs, "space-space-science-pack")
    end
    data_util.tech_remove_prerequisites("space-science-pack", {"kr-singularity-lab"})
    data_util.tech_add_ingredients("space-science-pack", {"se-rocket-science-pack"})
    data_util.tech_add_prerequisites("space-science-pack",
      {"kr-imersium-processing", "se-processing-iridium", "se-processing-holmium", "se-processing-beryllium", "se-processing-vitamelange"}
    )

  end

  if data.raw.tool["basic-tech-card"] then
    data_util.tech_remove_ingredients("se-medpack", {"automation-science-pack"})
    data.raw.technology["se-medpack"].prerequisites = {}
  end

  if data.raw["assembling-machine"]["kr-fuel-refinery-spaced"] then
    if not data_util.table_contains(data.raw["assembling-machine"]["kr-fuel-refinery-spaced"].crafting_categories, "fuel-refining") then
      table.insert(data.raw["assembling-machine"]["kr-fuel-refinery-spaced"].crafting_categories, "fuel-refining")
    end
    data.raw["assembling-machine"]["kr-fuel-refinery-spaced"].localised_description = {"space-exploration.structure_description_spaced", ""}
  end

  if mods["k2se-compatibility"] and k2se_compatibility_apply_changes then
    k2se_compatibility_apply_changes()
  end

  -- fix k2 doing something to the lab
  for _, lab in pairs(data.raw.lab) do
    for i, item in pairs(lab.inputs) do
      if item == "se-deep-space-science-pack" then
        lab.inputs[i] = nil
      end
    end
  end

  require("prototypes/phase-4/krastorio2/matter")

  -- fix power progression
  -- higher tech means more power density
  -- more complicated setups mean higher energy efficiency (closer to 1).
  -- simpler setups mean reduced energy efficiency.

  -- fuild isothermic generator is 0.75 normally
  -- both convert fuel to energy directly so shouldn't be over 80% efficiency.
  -- fuild isothermic generator is less space efficient.
  data.raw["generator"]["kr-gas-power-station"].energy_source.effectivity = 0.75
  data.raw["generator"]["kr-gas-power-station"].collsion_mask = --land
    {"item-layer","object-layer","player-layer","water-tile",space_collision_layer, spaceship_collision_layer}
  data.raw["generator"]["se-fluid-burner-generator"].collsion_mask = --space
    {"water-tile","ground-tile","item-layer","object-layer","player-layer"}

  data.raw["generator"]["kr-advanced-steam-turbine"].max_power_output = "50MW"
  data.raw["burner-generator"]["kr-antimatter-reactor"].burner.effectivity = 0.8
  data.raw["burner-generator"]["kr-antimatter-reactor"].max_power_output = "2GW"
  data.raw.item["charged-antimatter-fuel-cell"].fuel_value = "100GJ" --same as antimatter cell

  data.raw["burner-generator"]["kr-antimatter-reactor"].collsion_mask = --land, space, not spaceship
    {"item-layer","object-layer","player-layer","water-tile", spaceship_collision_layer}


  data_util.enable_recipe("first-aid-kit")
  data_util.replace_or_add_ingredient("se-medpack", "iron-plate", "first-aid-kit", 1)
  data_util.replace_or_add_ingredient("se-medpack", "wood", "wood", 2)
  data_util.replace_or_add_ingredient("se-medpack", "raw-fish", "raw-fish", 1)
  data_util.replace_or_add_ingredient("se-medpack", "biomass", "biomass", 1)
  data_util.replace_or_add_ingredient("se-medpack-plastic", "iron-plate", "first-aid-kit", 1)
  local first_aid_kit_2 = table.deepcopy(data.raw.recipe["first-aid-kit"])
  first_aid_kit_2.name = "first-aid-kit-fish"
  data:extend({first_aid_kit_2})
  data_util.replace_or_add_ingredient("first-aid-kit-fish", "biomass", "raw-fish", 1)

  data.raw.capsule["first-aid-kit"].subgroup = "capsule"
  data.raw.capsule["first-aid-kit"].order = "a"
  data.raw.capsule["first-aid-kit"].stack_size = 20
  data.raw.capsule["first-aid-kit"].capsule_action = {
    attack_parameters = {
      ammo_category = "capsule",
      ammo_type = {
        action = {
          action_delivery = {
            target_effects = {
              damage = {
                amount = -25,
                type = "poison"
              },
              type = "damage"
            },
            type = "instant"
          },
          type = "direct"
        },
        category = "capsule",
        target_type = "position"
      },
      cooldown = 10,
      range = 0,
      type = "projectile"
    },
    type = "use-on-self"
  }

  --Thanks to PeterHan5
  krastorio.recipes.replaceProduct("se-core-fragment-imersite", "raw-imersite", {type="item", name="raw-imersite", amount=10})
  krastorio.recipes.replaceProduct("se-core-fragment-rare-metals", "raw-rare-metals", {type="item", name="raw-rare-metals", amount=10})
  krastorio.recipes.replaceProduct("se-core-fragment-mineral-water", "mineral-water", {type="fluid", name="mineral-water", amount=50})
  krastorio.recipes.replaceProduct("se-core-fragment-crude-oil", "crude-oil", {type="fluid", name="crude-oil", amount=50})

  data_util.replace_or_add_ingredient("se-bio-sludge-from-wood", "wood", "wood", 50)
  data_util.replace_or_add_ingredient("se-bio-sludge-from-wood", "se-space-water", "se-space-water", 20, true)

  -- Biosluge balance
  local biomass_recipe = table.deepcopy(data.raw.recipe["se-bio-sludge-from-wood"])
  biomass_recipe.name = "se-bio-sludge-from-biomass"
  biomass_recipe.icons = {
    { icon = data.raw.fluid[data_util.mod_prefix .. "bio-sludge"].icon, scale = 1, icon_size = 64  },
    { icon = data.raw.item["biomass"].icon, scale = 0.75/2, icon_size = 64  },
  }
  biomass_recipe.localised_name = {"recipe-name.se-bio-sludge-from-biomass"},
  data:extend({biomass_recipe})
  data_util.replace_or_add_ingredient("se-bio-sludge-from-biomass", "wood", "biomass", 50)
  data_util.replace_or_add_ingredient("se-bio-sludge-from-biomass", "se-space-water", "se-space-water", 10, true)
  data_util.tech_lock_recipes("se-space-biochemical-laboratory", {"se-bio-sludge-from-biomass"})

  data.raw.recipe["se-processing-unit-holmium"].normal = nil
  data.raw.recipe["se-processing-unit-holmium"].expensive = nil
  data.raw.recipe["se-processing-unit-holmium"].ingredients = {
    {"advanced-circuit", 3},
    {"rare-metals", 2},
    {"se-holmium-cable", 8},
    {type = "fluid", name="sulfuric-acid", amount=4}
  }
  data.raw.recipe["se-processing-unit-holmium"].result_count = 2

  data.raw.technology["kr-energy-shield-mk3-equipment"] = nil
  data.raw.technology["kr-energy-shield-mk4-equipment"] = nil

  data.raw.technology["energy-shield-equipment"].prerequisites = {"se-holmium-cable", "military-science-pack", "se-adaptive-armour-2"}
  data.raw.technology["energy-shield-equipment"].unit.ingredients = { {"military-science-pack", 1}, {"se-energy-science-pack-1", 1}}

  data.raw.technology["energy-shield-mk2-equipment"].unit.ingredients = { {"military-science-pack", 1}, {"se-energy-science-pack-2", 1}}

  data.raw.technology["energy-shield-mk3-equipment"].unit.ingredients = { {"military-science-pack", 1}, {"se-energy-science-pack-3", 1}}

  data.raw.technology["energy-shield-mk4-equipment"].unit.ingredients = { {"military-science-pack", 1}, {"se-energy-science-pack-4", 1}}

  data_util.tech_add_prerequisites("energy-shield-mk5-equipment", { "se-deep-space-science-pack-1"})
  data.raw.technology["energy-shield-mk5-equipment"].unit.ingredients = { {"military-science-pack", 1}, {"se-energy-science-pack-4", 1}, {"se-deep-space-science-pack-1", 1}}

  data_util.tech_add_prerequisites("energy-shield-mk6-equipment", {"kr-singularity-tech-card"})
  data.raw.technology["energy-shield-mk6-equipment"].unit.ingredients = {{"military-science-pack", 1}, {"se-energy-science-pack-4", 1}, {"se-deep-space-science-pack-4", 1}, {"singularity-tech-card", 1}}

  krastorio.icons.setTechnologyIcon("energy-shield-equipment", kr_technologies_icons_path .. "energy-shield-mk1-equipment.png", 256, 4)
  krastorio.icons.setTechnologyIcon("energy-shield-mk2-equipment", kr_technologies_icons_path .. "energy-shield-mk2-equipment.png", 256, 4)

  if data.raw["spider-vehicle"]["spidertron"].energy_source.fuel_categories then
    data_util.tech_add_prerequisites("spidertron", {"uranium-processing"})
    table.insert(data.raw["spider-vehicle"]["spidertron"].energy_source.fuel_categories, "nuclear")
  end

  local pack_progression = {"automation-science-pack", "logistic-science-pack", "chemical-science-pack", "production-science-pack",
  "se-rocket-science-pack", "se-biological-science-pack-1", "se-biological-science-pack-2", "space-science-pack", "se-biological-science-pack-3", "se-biological-science-pack-4",
  "se-deep-space-science-pack-1", "advanced-tech-card", "se-deep-space-science-pack-2", "se-deep-space-science-pack-3", "se-deep-space-science-pack-4", "singularity-tech-card"}
  local last_valid = nil
  for i = 1, 16 do
    if data.raw.technology["mining-productivity-"..i] then
      data.raw.technology["mining-productivity-"..i].unit.ingredients = {}
      if i == 1 then
        data.raw.technology["mining-productivity-"..i].prerequisites = {"electric-mining"}
      else
        data.raw.technology["mining-productivity-"..i].prerequisites = {"mining-productivity-"..last_valid}
      end
      for j = math.max(1, i-12), i do
        data_util.tech_add_ingredients("mining-productivity-"..i, {pack_progression[j]})
      end
      last_valid = i
    end
  end

  local pack_progression = {"automation-science-pack", "logistic-science-pack", "chemical-science-pack", "utility-science-pack",
  "se-rocket-science-pack", "se-material-science-pack-1", "se-material-science-pack-2", "space-science-pack", "se-material-science-pack-3", "se-material-science-pack-4",
  "advanced-tech-card", "singularity-tech-card"}
  local last_valid = nil
  for i = 1, 10 do
    if data.raw.technology["worker-robots-speed-"..i] then
      data.raw.technology["worker-robots-speed-"..i].unit.ingredients = {}
      if i > 1 then
        data.raw.technology["worker-robots-speed-"..i].prerequisites = {"worker-robots-speed-"..last_valid}
      end
      for j = math.max(1, i-6), i+2 do
        data_util.tech_add_ingredients("worker-robots-speed-"..i, {pack_progression[j]})
      end
      last_valid = i
    end
  end

  if data.raw.technology["kr-military-5"] then
    local tech = table.deepcopy(data.raw.technology["kr-military-5"])
    tech.name = "kr-imersite-weapons"
    tech.effects = {}
    tech.prerequisites = {
      "kr-military-5",
      "kr-imersium-processing",
      "kr-advanced-tech-card",
    }
    tech.unit.ingredients = {
        {"production-science-pack", 1},
        {"utility-science-pack", 1},
        {"military-science-pack", 1},
        {"advanced-tech-card", 1},
    }
    data:extend({tech})
    data_util.tech_lock_recipes("kr-imersite-weapons", {"impulse-rifle", "impulse-rifle-ammo", "imersite-rifle-magazine", "imersite-anti-material-rifle-magazine"})
    data_util.replace_or_add_ingredient("impulse-rifle", "steel-plate", "imersium-plate", 5)
  end

  for _, prototype in pairs({
    data.raw["accumulator"]["kr-intergalactic-transceiver"],
    data.raw["electric-energy-interface"]["kr-activated-intergalactic-transceiver"]}) do
    if not prototype.collision_mask then
      prototype.collision_mask = {"item-layer","object-layer","player-layer","water-tile"}
    end
    if not data_util.table_contains(prototype.collision_mask, spaceship_collision_layer) then
      table.insert(prototype.collision_mask, spaceship_collision_layer)
    end
  end

end
