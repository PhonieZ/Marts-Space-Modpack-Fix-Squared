local data_util = require("data_util")

local modules_per_tier = 3

local function craft_time(tier)
  return 2^tier
end

local function module_name(base_name, tier)
  local name = base_name
  if tier > 1 then
    name = name .. "-"..tier
  end
  return name
end

for _, base_name in pairs({"productivity-module", "speed-module", "effectivity-module"}) do
  for tier = 1, 9 do
    local name = module_name(base_name, tier)
    if tier > 1 then
      local tier_down = module_name(base_name, tier-1)
      data_util.replace_or_add_ingredient(name, tier_down, tier_down, modules_per_tier)
    end
    data_util.set_craft_time(name, craft_time(tier))
  end
end
