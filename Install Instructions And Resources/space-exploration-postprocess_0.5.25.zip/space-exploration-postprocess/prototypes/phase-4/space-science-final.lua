local data_util = require("data_util")

--[[
  What to do: 
    swap keywords to ingore to an easy to expand list
    get rid of recipes ingredients AND results that interact with space science, if it's getting deleted/replaced
    kill recipes that end up with zero ingredients/results as a result of above
    Also get rid of rocket launch products?
]]

-- check to see if there is any way to make space science.
local space_science_name = "space-science-pack"
local rocket_science_name = data_util.mod_prefix .. "rocket-science-pack"
local allow_destroying_recipes = true

local function has_keyword (word, list)
  for _, keyword in pairs (list) do
    if string.find(word, keyword, 1, true) then
      return true
    end
  end
  return false
end

local stack_keywords = { -- easier to add new exceptions to the source finding, as well as using it in other spots
  "stack",    -- deadlock-stacking 
  "request",  -- transport-drones
  "compress", -- simple-compress?
  "store"     -- deep-storage-unit
}

local function find_source_of(item_name)
  -- check for recipes.
  for _, recipe in pairs(data.raw.recipe) do
    if not has_keyword (recipe.name, stack_keywords) then
      for _, subname in pairs({"normal", "expensive"}) do
        local table = recipe
        if recipe[subname] then
          table = table[subname]
        end
        if table.result == item_name then
          return true
        end
        if table.results then
          for _, result in pairs(table.results) do
            for _, name in pairs(result) do
              if name == item_name then
                return true
              end
            end
          end
        end
      end
    end
  end

  for _, item in pairs(data.raw.item) do
    if item.rocket_launch_product and (item.rocket_launch_product[1] == item_name or item.rocket_launch_product.name == item_name) then
      return true
    end
  end
end

local space_science_found = find_source_of(space_science_name)
if space_science_found then
  log("Space science source was found. Go to no-conflict mode.")
else -- do we want to have an option to add an alternative space recipe even if a source was detected? there's a possibility that the source will require space science to access, as a T2 satellite of some sorts...
  if settings.startup["se-space-science-pack"].value == "OptimisationUranium" then
    log("No space science source was found. Use alternate recipe:"..settings.startup["se-space-science-pack"].value)
    data:extend({
      {
          type = "recipe",
          name = data_util.mod_prefix .. "space-science-pack",
          enabled = false,
          energy_required = 10,
          ingredients = {
            { "uranium-235", 1 },
            { "processing-unit", 1 },
            { data_util.mod_prefix .. "cryonite-rod", 2 },
          },
          results = {
            {"space-science-pack", 2},
          },
          icon = "__space-exploration-graphics__/graphics/icons/beaker/white.png",
          icon_size = 64,
          main_product = "space-science-pack",
          requester_paste_multiplier = 1,
          subgroup = "science-pack",
      },
    })
    data_util.recipe_require_tech(data_util.mod_prefix .. "space-science-pack", space_science_name)
  elseif settings.startup["se-space-science-pack"].value == "OptimisationFish" then
    log("No space science source was found. Use alternate recipe:"..settings.startup["se-space-science-pack"].value)
    data:extend({
      {
          type = "recipe",
          name = data_util.mod_prefix .. "space-science-pack",
          enabled = false,
          energy_required = 10,
          ingredients = {
            { "raw-fish", 1 },
            { data_util.mod_prefix .. "vitamelange-roast", 1 },
            { data_util.mod_prefix .. "vulcanite", 2 },
            { "coal", 2 },
          },
          results = {
            {"space-science-pack", 2},
          },
          icon = "__space-exploration-graphics__/graphics/icons/beaker/white.png",
          icon_size = 64,
          main_product = "space-science-pack",
          requester_paste_multiplier = 1,
          subgroup = "science-pack",
      },
    })
    data_util.recipe_require_tech(data_util.mod_prefix .. "space-science-pack", space_science_name)
  elseif settings.startup["se-space-science-pack"].value == "Replace" then
    log("No space science source was found. Replace it.")
    for _, technology in pairs(data.raw.technology) do
      local add_prereq = false
      local add_ingredient = false
      if technology.prerequisites then
        for i, prereq in pairs(technology.prerequisites) do
          if prereq == space_science_name then
            add_prereq = true
          end
        end
      end
      for i, ingredient in pairs(technology.unit.ingredients) do
        if ingredient[1] == space_science_name or ingredient.name == space_science_name then
          add_ingredient = true
        end
      end
      data_util.tech_remove_prerequisites(technology.name, {space_science_name})
      data_util.tech_remove_ingredients(technology.name, {space_science_name})
      if add_prereq then
        data_util.tech_add_prerequisites(technology.name, {rocket_science_name})
      end
      if add_ingredient then
        data_util.tech_add_ingredients(technology.name, {rocket_science_name})
      end
    end

    for _, lab in pairs(data.raw.lab) do
      for i, input in pairs(lab.inputs) do
        if input == space_science_name then
          lab.inputs[i] = nil
        end
      end
    end

    data.raw.technology[space_science_name] = nil
    data.raw.item[space_science_name] = nil
    data.raw.tool[space_science_name] = nil




    for _, recipe in pairs (data.raw.recipe) do -- go over ALL parts of the recipe that may have space science
      for _, diff in pairs ({recipe, recipe.normal, recipe.expensive}) do

        if diff.ingredients then
          for _, ing in pairs (diff.ingredients) do
            if ing[1] == space_science_name then
              ing[1] = rocket_science_name
            elseif ing.name == space_science_name then
              ing.name = rocket_science_name
            end
          end
        end

        if diff.result and diff.result == space_science_name then
          diff.result = rocket_science_name
        end
        if diff.main_product and diff.main_product == space_science_name then
          diff.main_product = rocket_science_name
        end

        if diff.results then
          for _, res in pairs (diff.results) do
            if res[1] == space_science_name then
              res[1] = rocket_science_name
            elseif res.name == space_science_name then
              res.name = rocket_science_name
            end
          end
        end

      end
    end

  else
    log("No space science source was found. Remove it.")
    local names = {} -- move technology removal down, so that we can remove empty recipes using the same loop
    
    for _, lab in pairs(data.raw.lab) do
      for i, input in pairs(lab.inputs) do
        if input == space_science_name then
          lab.inputs[i] = nil
        end
      end
    end

    data.raw.technology[space_science_name] = nil
    data.raw.item[space_science_name] = nil
    data.raw.tool[space_science_name] = nil


    for _, recipe in pairs (data.raw.recipe) do
        local empty = {} 
        --log (serpent.block (recipe))

        for _, diff in pairs ({base = recipe, normal = recipe.normal, expensive = recipe.expensive}) do
            if (diff.ingredients and #diff.ingredients > 0) or diff.result or (diff.results and #diff.results > 0) then -- let's not touch recipes that were already empty
              empty[_] = {}

              if diff.ingredients then

                for i = #diff.ingredients, 1, -1 do
                    local ing = diff.ingredients[i]
                    --log (serpent.block (ing))
                    if ing and (ing[1] and ing[1] == space_science_name or ing.name and ing.name == space_science_name) then
                      table.remove (diff.ingredients, i)
                    end
                end
                if #diff.ingredients == 0 then
                  empty[_].ingredients = true
                end
              end


              if diff.result and diff.result == space_science_name then
                diff.result = nil
              end
              if diff.main_product and diff.main_product == space_science_name then
                diff.main_product = nil
              end

              if diff.results then
                for i = #diff.results, 1, -1 do
                    local res = diff.results[i]
                    if res and (res[1] and res[1] == space_science_name or res.name and res.name == space_science_name) then
                      table.remove (diff.results, i)
                    end
                end
              end
              if (diff.results and #diff.results == 0 or not diff.results) and not diff.result then
                empty[_].results = true
              end
            end
        end
        -- removing empty recipes:
        -- recipes can end up either with no ingredients, no results, or no either
        -- do we destroy them if either ingredients or results are empty, or only when both?
        --log (recipe.name .. ", " .. serpent.block (empty) .. ", " .. (next(empty) or "none") .. ", " .. serpent.block (recipe))
        if ((empty.base      and (empty.base.ingredients       and empty.base.results)) or not empty.base) and
          ((empty.normal     and (empty.normal.ingredients     and empty.normal.results)) or not empty.normal) and
          ((empty.expensive  and (empty.expensive.ingredients  and empty.expensive.results)) or not empty.expensive) and
          next(empty) then --either the difficulities don't exist, or they do and are empty
          if allow_destroying_recipes then
            if not recipe.hidden then --hidden recipes can have a reason to exist, for mods to work
              table.insert (names, recipe.name)
              debug_log ("recipe " .. recipe.name .. " doesn't make or consume anything, remove it.")
            end
          end
        end
    end

    for _, name in pairs (names) do
      data.raw.recipe[name] = nil
    end

    for _, technology in pairs(data.raw.technology) do
      data_util.tech_remove_prerequisites(technology.name, {space_science_name})
      data_util.tech_remove_ingredients(technology.name, {space_science_name})
      for _, name in pairs (names) do
          if technology.effects then
            data_util.remove_recipe_from_effects (technology.effects, name)
          end
      end
    end

  end

end
