local data_util = require("data_util")

local all_prerequisites_cache = {}

local function get_all_prerequisites(tech_name)
  -- cache to give this code a reasonable runtime
  if all_prerequisites_cache[tech_name] then return all_prerequisites_cache[tech_name] end

  local cache_value = {}
  local technology = data.raw.technology[tech_name]
  if technology and technology.prerequisites then
    for _, own_prerequisite in pairs(technology.prerequisites) do
      for pre_prerequisite, _ in pairs(get_all_prerequisites(own_prerequisite)) do
        cache_value[pre_prerequisite] = true
      end
      cache_value[own_prerequisite] = true
    end
  end
  all_prerequisites_cache[tech_name] = cache_value
  return cache_value
end

for tech_name, technology in pairs(data.raw.technology) do
  local own_prerequisites = technology.prerequisites
  if own_prerequisites then
    local pre_prerequisites = {}
    for _, own_prerequisite in pairs(own_prerequisites) do
      for pre_prerequisite, _ in pairs(get_all_prerequisites(own_prerequisite)) do
        pre_prerequisites[pre_prerequisite] = true
      end
    end
    for i=#own_prerequisites,1,-1 do
      if pre_prerequisites[own_prerequisites[i]] then
          table.remove(own_prerequisites, i)
      end
    end
  end
end