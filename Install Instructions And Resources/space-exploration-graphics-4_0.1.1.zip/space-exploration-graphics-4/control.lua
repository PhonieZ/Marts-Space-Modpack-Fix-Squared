function validate()
  if not game.active_mods["space-exploration"] then
    game.print("[color=red]You do not have Space Exploration installed. DO NOT SAVE THE GAME. Exit without saving, install Space Exploration, check for incompatibilities, and reload.[/color]")
  end
end

script.on_configuration_changed(validate)
script.on_event(defines.events.on_player_created, validate)
script.on_nth_tick(3600, validate)
